﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week09Homework
{
    class Professor : Member
    {
        //public string DepartmentCode { get; set; }

        //private string _number;
        //public string Number
        //{
        //    get { return _number; }
        //}
        //
        //private string _name;
        //public string Name
        //{
        //    get { return _name; }
        //    set { _name = value; }
        //}

        public override string ToString()
        {
            return $"[{Number}]{Name}";
        }

        public Professor(string number, string name, Department dept)
            : base(number, name, dept)
        {
            //_number = number;
            //_name = name;
            //DepartmentCode = deptcode;
        }
        public string Record()
        {
            return $"{Number}|{Name}|{Dept.Code}";
        }
        public static Professor Restore(string pcode , string pname, Department dept)
        {
            Professor pr = null;
            //참고
            try
            {
               pr = new Professor(pcode, pname, dept);
            }
            catch (IndexOutOfRangeException ex)
            {
                MessageBox.Show("파일 포맷이 잘못되었음");
                Console.WriteLine(ex);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            if(pr == null)
            {
                MessageBox.Show("pr is empty !!");
            }
            return pr;
        }
    }
}
