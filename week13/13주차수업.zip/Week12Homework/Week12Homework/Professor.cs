﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week09Homework
{
    class Professor : Member , IFile
    {
        //public string DepartmentCode { get; set; }

        //private string _number;
        //public string Number
        //{
        //    get { return _number; }
        //}
        //
        //private string _name;
        //public string Name
        //{
        //    get { return _name; }
        //    set { _name = value; }
        //}

        public override string ToString()
        {
            return $"[{Number}]{Name}";
        }

        public Professor(string number, string name, Department dept)
            : base(number, name, dept)
        {
            //_number = number;
            //_name = name;
            //DepartmentCode = deptcode;
        }
        public string Record
        {
            get { return $"{Number}|{Name}|{Dept.Code}"; }
        }
        /* Dept.Code dept만 넣으면 객체를 넣게되는데 그러면 부서코드:부서이름 형태로 tostring()으로 
         저장된다. */

        public static Professor Restore(string record, Department [] departments )
        {
            /* 매개변수로 부서 배열 자체를 가져오면 됩니다. 
             * 입력 > 처리 > 출력 순으로 프로그램을 돌려야하는데 입력, 출력을 명시하면 
             코드를 짤 때 처리부분을 구상하기 더 유용하다!*/
            Professor prof = null;
            try
            {
                var sdatas = record.Trim ().Split ('|');
                var dept = departments.FirstOrDefault (m => m != null && m.Code == sdatas [2]);
                // &: 하나만 주면 뒤의 조건도 실행하고 마무리 지음, 그리고 null값이
                prof = new Professor (sdatas [0], sdatas [1], dept);
            }
            catch (Exception ex)
            {
                Console.WriteLine (ex);
                throw ex;
                /*에러를 포착하면 로그 기록 남기고 호출부로 throw해서 코드를 죽임.*/
            }
            return prof;
        }
    }
}
