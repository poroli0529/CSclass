﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proj_FinacialLedger_202244083
{
    abstract class Financial
    {
        protected Dictionary<DateTime, Info> _incomes;
        protected Dictionary<DateTime, Info> _expenditures;


        public int TotalIncome
        {
            get
            {
                int total = 0;
                foreach (var d in _incomes)
                {
                
                        total += d.Value.money;
                }
                return total;
            }
            
        }
        public int TotalExpenditures
        {
            get
            {
                int total = 0;
                foreach (var d in _incomes)
                {
                  
                        total += d.Value.money;
                }
                return total;
            }
        }
        public virtual bool RegIncome1(DateTime incomeData, string content, int money)
        {
            if (money < 0)
            {
                Console.WriteLine("금액 재입력");
                return false;
            }
            Info info = new Info(content, money);
            _incomes.Add(incomeData, info);
            return true;
        }
        public virtual bool RegIncome2(string content, int money) 
        {
            if (money < 0)
            {
                Console.WriteLine("금액 재입력");
                return false;
            }
            Info info = new Info(content, money);
            DateTime today = new DateTime();
            today = DateTime.Now;
            _incomes.Add(today, info);
            return true;
        }
        public virtual bool RegExpenditure1(DateTime expendData, string content, int money) 
        {
            if (money < 0)
            {
                Console.WriteLine("금액 재입력");
                return false;
            }
            _expenditures.Add(expendData,new Info(content, money));
            return true;
        }
        public virtual bool RegExpenditure2(string content, int money) {
            if (money < 0)
            {
                Console.WriteLine("금액 재입력");
                return false;
            }
            _expenditures.Add( DateTime.Now , new Info(content, money));
            return true;
        }

    }
}
