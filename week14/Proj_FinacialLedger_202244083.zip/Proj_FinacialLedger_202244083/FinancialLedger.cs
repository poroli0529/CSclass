﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proj_FinacialLedger_202244083
{
    class FinancialLedger : Financial {
        private int _year;
        private int _targetAmount;

        public FinancialLedger(int year , int targetAmount)
        {
            _year = year;
            _targetAmount = targetAmount;
        }
        public int Year
        {
            get
            {
                return _year;
            }
         
        }
        public int TargetAmount
        {
            get
            {
                return _targetAmount;
            }
           
        }
        public bool IsBlack
        {
            get
            {
                if (TargetAmount == 0 && TotalIncome > TotalExpenditures) 
                {
                    return true;
                }
                else if (TargetAmount != 0)
                {
                    int target = TotalIncome - TotalExpenditures;
                    if (target > _targetAmount)
                    {
                        return true;
                    }
                    return false;
                }
                else { return false; }
            }
        }

        public override bool RegIncome1(DateTime incomeData, string content, int money)
        {

            if (Year != incomeData.Year)
            {
                Console.WriteLine("다른년도");
                return false;
            }
            if (money < 0)
            {
                Console.WriteLine("금액 재입력");
                return false;
            }
            Info info = new Info(content, money);
            _incomes.Add(incomeData, info);
            return true;
        }

        public override bool RegIncome2(string content, int money)
        {
            if (money < 0)
            {
                Console.WriteLine("금액 재입력");
                return false;
            }
            Info info = new Info(content, money);
            DateTime today = new DateTime();
            today = DateTime.Now;

            if(today.Year != Year)
            {
                Console.WriteLine("목표 연도와 틀림.");
                return false;
            }
            _incomes.Add(today, info);
            return true;
        }

        public override bool RegExpenditure1(DateTime expendData, string content, int money)
        {
            if (Year != expendData.Year)
            {
                Console.WriteLine("다른년도");
                return false;
            }
            if (money < 0)
            {
                Console.WriteLine("금액 재입력");
                return false;
            }
            _expenditures.Add(expendData, new Info(content, money));
            return true;
        }
        public override bool RegExpenditure2(string content, int money)
        {
            if (money < 0)
            {
                Console.WriteLine("금액 재입력");
                return false;
            }

            DateTime now = DateTime.Now;
            _expenditures.Add(now, new Info(content, money));
            return true;
        }
    }
}
