﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proj_FinacialLedger_202244083
{
    class Info
    {
        public string Content { get; set; }
        public int money { get; set; }
        public Info(string c, int m)
        {
            Content = c;
            money = m;
        }
        public override string ToString()
        {
            return $"[{Content},{money}]";
        }


    }
}
