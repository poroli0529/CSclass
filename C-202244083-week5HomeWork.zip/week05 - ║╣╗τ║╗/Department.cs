﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week05
{
   
        public class Department
        {
            public string Code;
            public string Name;

            public override string ToString()
            {
                return $"[{Code}] {Name}";
            }
        }

        
    
}
