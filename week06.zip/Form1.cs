﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace week05
{

    public partial class Form1 : Form
    {
        //인스턴스 필드(변수), 멤버변수
        Department[] departments;
        List<Professor> professors;
        Dictionary<string,Student> students;
        
        //생성자
        //인스턴스 생성시 초기화가 필요한 코드를 
        //넣어준다.
        public Form1()
        {
            InitializeComponent();
            departments = new Department[100];
            professors = new List<Professor>();
            students = new Dictionary<string, Student>();

        }
        private void btnRegisterDepartment_Click(object sender, EventArgs e)
        {
            //(구현)학과코드가 비어있으면 메시지를 띄우고 포커스 이동한 후 종료한다.
            if (string.IsNullOrWhiteSpace(tbxDepartmentCode.Text))
            {
                MessageBox.Show("학과코드를 입력하세요.", "입력 오류");
                tbxDepartmentCode.Focus();
                return;
            }
            //(구현)학과이름이 비어있으면 메시지를 띄우고 포커스 이동한 후 종료한다.
            if (string.IsNullOrWhiteSpace(tbxDepartmentName.Text))
            {
                MessageBox.Show("학과이름을 입력하세요.", "입력오류"); // 박스 텍스트! : 박스 캡션! 이순서로 코딩!
                tbxDepartmentName.Focus();
                return;
            }
            int index = -1;
            for (int i = 0; i < departments.Length; i++)
            {
                if (departments[i] == null)
                {
                    if (index < 0)
                    {
                        index = i;
                    }
                    //break;
                }
                else
                {
                    if (departments[i].Code == tbxDepartmentCode.Text)
                    {
                        //(구현)동일한 코드는 사용이 불가능하다는 메시지를 띄우고
                        MessageBox.Show("동일한 코드는 사용이 불가능합니다!", "동일코드");
                        //포커스 이동한다.
                        tbxDepartmentCode.Focus();
                        return;
                    }
                }
            }
            if (index < 0)
            {
                //(구현)더 이상 신규 학과정보를 입력할 수 없을 메세지로 알린다.
                MessageBox.Show("더 이상 신규 학과정보를 입력할 수 없습니다.", "초과입력");
                return;
            }
            Department dept = new Department();
            dept.Code = tbxDepartmentCode.Text;
            dept.Name = tbxDepartmentName.Text;
            departments[index] = dept;
            lbxDepartment.Items.Add(dept);
            //추후 아래 코드는 삭제한다.
            // 확인
        }
        private void btnRemoveDepartment_Click(object sender, EventArgs e)
        {
            if (lbxDepartment.SelectedIndex < 0)
            {
                //(구현) 삭제할 학과를 선택하라는 메세지를 띄운다.
                MessageBox.Show("삭제할 학과 선택하세요!", "삭제 학과 선택");
                return;
            }
            //is 연산자 , 타입 확인용으로 사용.
            if (lbxDepartment.SelectedItem is Department)
            {
                var target = (Department)lbxDepartment.SelectedItem;
                for (int i = 0; i < departments.Length; i++)
                {
                    if (departments[i] != null && departments[i] == target)
                    {
                        departments[i] = null;
                        break;
                    }
                }
                lbxDepartment.Items.RemoveAt(lbxDepartment.SelectedIndex);
                lbxDepartment.SelectedIndex = -1;
            }
        }


        private void btnRemoveDepartment_Click_1(object sender, EventArgs e)
        {
            // 아무 것도 선택안됬는데 눌렸을경우
            if (lbxDepartment.SelectedIndex == -1)
            {
                MessageBox.Show("삭제할 학과를 선택하세요!", "삭제 오류");
                return;
            }
            // 선택된것이 잘못된것일경우 Department형인지 확인하고 삭제해야함. 
            if (lbxDepartment.SelectedItem is Department)
            {
                Department target = (Department)lbxDepartment.SelectedItem;
                for (int i = 0; i < departments.Length; i++)
                {
                    if (departments[i] != null && departments[i] == target)
                    {
                        departments[i] = null;
                        break;
                    }
                }


                lbxDepartment.Items.RemoveAt(lbxDepartment.SelectedIndex);
                lbxDepartment.SelectedIndex = -1; // 선택을 해제한다는 의미입니다.
            }
        }


        private void tabMain_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (tabMain.SelectedIndex)
            {
                case 0:
                    break;
                case 1:
                    cmbProfessorDepartment.Items.Clear();
                    foreach (var department in departments)
                    {
                        if (department != null)
                        {
                            cmbProfessorDepartment.Items.Add(department);
                        }
                    }
                    cmbProfessorDepartment.SelectedIndex = -1;
                    lbxProfessor.Items.Clear();
                    break;

                case 2:
                    
                    cmbDepartment.Items.Clear();
                    for (int i = 0; i < departments.Length; i++)
                    {
                        if (departments[i] != null)
                        {
                            cmbDepartment.Items.Add(departments[i]);
                        }
                    }
                    cmbDepartment.SelectedIndex = -1;

                    // 지도교수 콤보박스 초기화
                    cmbAdvisor.Items.Clear();
                    break;
                default:
                    break;
            }
        }
        private void cmbProfessorDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            //index값 검사해서 진행여부 결정
            //(구현) 조회할 학과를 선택하라는 메세지를 띄우고 종료한다.
            if (cmbProfessorDepartment.SelectedIndex == -1) // 콤보박스의 보기가 0~n까지야. 그래서 -1은 선택이 되지않았다고하는거야.
            {
                MessageBox.Show("조회할 학과를 선택하세요.", "학과 선택 진행");
                return;
            }

            lbxProfessor.Items.Clear();
            //as 형변환 연산자.
            //형변환이 정상적이지 않으면 null 반환.
            var department = cmbProfessorDepartment.SelectedItem as Department;
            if (department != null)
            {
                foreach (var professor in professors)
                {
                    if (professor != null
                        && professor.DepartmentCode
                        == department.Code)
                    {
                        lbxProfessor.Items.Add(professor);
                    }
                }
            }
        }


        private void btnRegisterProfessor_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(tbxProfessorName.Text))
            {
                MessageBox.Show("교수 이름을 입력하세요.", "입력 오류");
                tbxProfessorName.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(tbxProfessorNumber.Text))
            {
                MessageBox.Show("교수 이름을 입력하세요.", "입력 오류");
                tbxProfessorNumber.Focus();
                return;
            }
            if (cmbProfessorDepartment.SelectedIndex == -1)
            {
                MessageBox.Show("교수 학과를 입력하세요.", "입력 오류");
                cmbProfessorDepartment.Focus();
                return;
            }
            for (int i = 0; i < professors.Count; i++)
            {
                if (professors[i] != null &&
                    professors[i].Number == tbxProfessorNumber.Text)
                {
                    MessageBox.Show("중복된 교수번호입니다. 다른 번호를 입력하세요.", "중복 오류");
                    tbxProfessorNumber.Focus();
                    return;
                }
            }

            Department selectedDept = cmbProfessorDepartment.SelectedItem as Department;

            Professor newProf = new Professor()
            {
                Name = tbxProfessorName.Text,
                Number = tbxProfessorNumber.Text,
                DepartmentCode = selectedDept.Code
            };

            professors.Add(newProf);
            lbxProfessor.Items.Add(newProf);

            // 초기화
            tbxProfessorName.Clear();
            tbxProfessorNumber.Clear();
            cmbProfessorDepartment.SelectedIndex = -1;
            tbxProfessorName.Focus();


        }
        private void btnRemoveProfessor_Click(object sender, EventArgs e)
        {
            // 아무 것도 선택안됬는데 눌렸을경우
            if (lbxProfessor.SelectedIndex == -1)
            {
                MessageBox.Show("삭제 교수정보를 선택하세요!", "삭제 오류");
                return;
            }
            // 선택된것이 잘못된것일경우 Department형인지 확인하고 삭제해야함. 
            if (lbxProfessor.SelectedItem is Professor)
            {
                Professor target = (Professor)lbxDepartment.SelectedItem;

                professors.Remove(target);

                // 리스트박스에서도 제거
                lbxProfessor.Items.Remove(target);

                // 선택 해제
                lbxProfessor.SelectedIndex = -1;

            }
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            tbxNumber.Text = "20";
            tbxBirthYear.Text = "20";
            tbxName.Text = null;
            tbxBirthMonth.Text = null;
            tbxBirthDay.Text = null;
            cmbDepartment.Text = null;
            cmbAdvisor.Text = null;
            cmbYear.Text = null;
            cmbClass.Text = null;
            cmbRegStatus.Text = null;
            tbxAddress.Text = null;
            tbxContact.Text = null;
        }
        private void cmbClass_DropDown(object sender, EventArgs e)
        {
            cmbClass.Items.Clear();
            for (int i = 0; i <= 2; i++)
            {
                cmbClass.Items.Add(('A' + i).ToString());
            }
            
        }
        private void cmbYear_DropDown(object sender, EventArgs e)
        {
            cmbYear.Items.Clear();
            for(int i =1; i <= 4; i++)
            {
                cmbYear.Items.Add(i);
            }
            
        }
        private void cmbRegStatus_DropDown(object sender, EventArgs e)
        {
            string[] arr = {"퇴학" ,"휴학","졸업","재학" };
            cmbRegStatus.Items.Clear();
            for(int i = arr.Length - 1 ; i>=0; i--)
            {
                cmbRegStatus.Items.Add(arr[i].ToString());
            }
            
        }

        Student selectedStudent = null;
        private void btnRegister_Click(object sender, EventArgs e)
        {
            if (selectedStudent == null)
            {
                // 기존 정보 변경
                RegisterStudent();
            }
            else
            {
                // 신규 정보 생성, call
                UpdateStudent();
            }
        }

        private void RegisterStudent()
        {
            // Trim : 공백제거 
            var number = tbxNumber.Text.Trim();
            // 학번이 있다는 걸 확인
            if (true == students.ContainsKey(number)) // 키 값으로만 판단해서 반복X
            {
                tbxNumber.Focus();
                return;
            }
            Student student = new Student();
            student.Number = number;
            student.Name = tbxName.Text.Trim();

            int birthYear, birthMonth;//, birthDay; // 년월일을 다룰 일이 많으니까 datetime
            if(int.TryParse(tbxBirthYear.Text, out birthYear))
            {// 정상적으로 들어왔을경우 

            }else
            {// 비정상적 입력
                return;
            }
            if (int.TryParse(tbxBirthMonth.Text, out birthMonth))
            {// 정상적으로 들어왔을경우 

            }
            else
            {// 비정상적 입력
                return;
            }
            if (int.TryParse(tbxBirthDay.Text, out int birthDay))
            {// 정상적으로 들어왔을경우 

            }
            else
            {// 비정상적 입력
                return;
            }
            //현재 시스템 시간 : DateTime.now; 
            student.BirthInfo = 
                new DateTime(birthYear, birthMonth, birthDay);

            if(cmbDepartment.SelectedIndex < 0)
            {
                // cmbDepartment.Focus();
                // return;
                student.DepartmentCode = null;
            }
            else
            {
                student.DepartmentCode
                    = (cmbDepartment.SelectedItem as Department).Code;
            }
            students[number] = student; // 딕셔너리에 데이터 추가방법1(특징: 중복불허)
                                        // students.Add(number, student); //딕셔너리에 데이터 추가방법2(특징: 중복허용)
            lbxDictionary.Items.Add(student);
        }

        private void UpdateStudent() // definition
        {
            throw new NotImplementedException(); 

        }

        private void lbxDictionary_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(lbxDictionary.SelectedIndex < 0)
            {
                return;
            }
            selectedStudent = (lbxDictionary.SelectedItem as Student);

            btnNew_Click(this, EventArgs.Empty);
            btnNew_Click(sender, EventArgs.Empty);

            if (selectedStudent != null)
            {   // 선택된 학생의 정보 출력
                DisplaySelectedStudent(selectedStudent);
            }
        }

        private void DisplaySelectedStudent(Student student)
        {
            // this : 이름이 같은 인스턴스 필드와 지역변수를 전환 할 수 있다.
            tbxNumber.ReadOnly = true;
            tbxNumber.Text = student.Number;
            tbxBirthYear.Text
                = student.BirthInfo.Year.ToString();
        }
    }
}



