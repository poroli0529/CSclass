﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week05
{
    public class Professor
    {
        public string DepartmentCode;
        public string Number;
        public string Name;

        public override string ToString()
        {
            return $"[{Number}]{Name}";
        }
    }
}
